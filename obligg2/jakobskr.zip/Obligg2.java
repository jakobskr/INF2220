import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;

class Obligg2 {
int antallTasks = 0;
ArrayList<Task> tasks = new ArrayList<Task>();
ArrayList<Task> uncompletedTasks = new ArrayList<Task>();
ArrayList<Task> currentTasks = new ArrayList<Task>();

Task startTask,sluttTask;
Koe<Task> vei = new Koe<Task>();


  public void lesFraFil(String filnavn) throws Exception {
    File fil = new File(filnavn);
    Scanner filscan = new Scanner(fil);
    String temp = "";
    antallTasks = filscan.nextInt();
    filscan.nextLine();
    filscan.nextLine();
    while(filscan.hasNextLine()) {
      temp = filscan.nextLine();
      tasks.add(new Task(temp.split("\\s+")));
    }
    setEdges();
    //finner start noden
    for (Task t: tasks) {
      if (t.getinEgde().size() == 0 && !t.visited) {
        startTask = t;
      }
    }
  }

  //metode for aa sette kantene, kalles foer hver sortering
  public void setEdges() {
    int[] temparr;
    for (Task t: tasks) {
      t.getOutEgde().clear();
      t.getinEgde().clear();
    }
    for (Task t : tasks) {
      temparr = t.getPredecessors();
      for (int i: temparr) {
        t.setInEdge(tasks.get(i - 1));
        tasks.get(i - 1).setOutEgde(t);
      }
    }
  }

  public void print() {
    for (Task t : tasks) {
    System.out.printf("\nID: %d Name: %s Time: %d MP: %d EST: %d LST %d Slack %d",
    t.id,t.name,t.time,t.staff,t.earliestStart,(t.latestfinish - t.time),t.slack);
    }
    System.out.println();
  }

  public void realizability2() {
    realizability2(startTask, new ArrayList<Task>());
    System.out.println("The project is realizable!");
    for (Task t: tasks) {
      t.status = 0;
    }
  }

  public void realizability2(Task v, ArrayList<Task> log) {
    log.add(v);
    if (v.status == 1) {
      System.out.println("Loop found\nProject not realizable, Printing the loop");
      for (Task t: log) {
        System.out.println(t);
      }
      System.exit(0);
    }
    else if (v.status == 0) {
      v.status = 1;
      for (Task w: v.outEdges) {
        realizability2(w, log);
      }
      v.status = 2;
    }
  }

  public void simulateProjecFastest() {
    int teller = 0;
    String utprint;
    boolean utprintEndret;
    ArrayList<Task> tempL = new ArrayList<Task>();
    for (Task t: tasks) {
      uncompletedTasks.add(t);
    }
    while(!currentTasks.isEmpty() || !uncompletedTasks.isEmpty()) {
      tempL.clear();
      utprint = "time: " + teller + "\n";
      utprintEndret = false;

      for (Task t: currentTasks) {
        if (t.getEarlieststart() + t.time == teller) {
          tempL.add(t);
          utprint += ("Finished Task " + t.id + " \n");
          utprintEndret = true;
        }
      }
      //for aa unngaa concurrentmodification
      for (Task t: tempL) {
        currentTasks.remove(t);
      }
      tempL.clear();
      for (Task t: uncompletedTasks) {
        if (teller == t.getEarlieststart()) {
          currentTasks.add(t);
          tempL.add(t);
          utprint += ("Starting Task " + t.id + "\n");
          utprintEndret = true;
        }
      }
      //for aa unngaa concurrentmodification
      for (Task t: tempL) {
        uncompletedTasks.remove(t);
      }
      if (utprintEndret) {
        System.out.println(utprint);
      }
      teller++;
    }
    System.out.println("Shortest time to complete the task is " + (teller-1));
  }

  public void setEarliest() {
    for (Task t: tasks) {
      if (t.inEdges.size() == 0) {
        t.earliestStart(0);
      }
    }
  }

  public void latestTask() {
    sluttTask = startTask;
    for (Task t: tasks) {
      if (sluttTask.earliestStart + sluttTask.time < t.earliestStart + t.time) {
        sluttTask = t;
      }
    }
    sluttTask.latestfinish = sluttTask.earliestStart + sluttTask.time;
  }

  public void setSlack() {
    for (Task t: tasks) {
      t.slack();
    }
    for (Task t: tasks) {
    }
  }

  public void latestStart() {
    latestTask();
    latestStart(sluttTask);
  }

  public void latestStart(Task s) {
    Koe<Task> koe = new Koe<Task>();
    Task v;
    for (Task t: tasks) {
      t.latestfinish = s.latestfinish;
      t.status = t.outEdges.size();
      if (t.outEdges.size() == 0) {
        koe.settInn(t);
      }
    }
    while (!koe.erTom()) {
      v = koe.fjern();
      for (Task t: v.inEdges) {
        if (v.latestfinish - v.time < t.latestfinish) {
          t.latestfinish = v.latestfinish - v.time;
        }
        t.status--;
        if (t.status == 0) {
          koe.settInn(t);
        }
      }
    }
  }

  public void printE() {
    for (Task t: vei) {
      System.out.print(t.id + " ");
      t.printEarliest();
      System.out.println();
    }
  }

  public static void main(String[] args) throws Exception{
    Obligg2 test = new Obligg2();
    if (args.length == 0) {
      System.out.println("Wrong usage of program\n correct usage: java Obligg2 <filename>.txt");
      System.exit(0);
    }
    test.lesFraFil(args[0]);
    System.out.println("\n" + args[0]);
    test.realizability2();
    test.setEarliest();
    test.latestStart();
    test.setSlack();
    test.print();
    test.simulateProjecFastest();
  }
}
