READ ME:

1
  compile the program with javac *.java
2.
  Main filen er i Obligg2.java
  kjører programmet med java Obligg2 <filnavn>.txt
3.
  programmet har ingen spesefikke antakelser.
4.
  Ignorer bladingen av engelsk og norsk.
5.
  alt funker, men er usikker på om jeg får riktige verdier.
