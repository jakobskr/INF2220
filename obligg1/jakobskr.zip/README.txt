1.
  Alle ord genereringen burde ha O(n) kompleksitet, altså en linær kjøretid. Selv om jeg noen steder har en for loop inni en for loop
  so looper de ikke på n, men på lengden til alfabetet 26, som da er en konstant, altså blir det da O(27n), som fortsatt gir linær kjøretid av programmet.
2.
  for å kompilere programmet så holder det med "javac BinTree.java" siden alt ligger i en fil. programmet trenger også txtfilen, dic.txt for å kunne kompilere.
3.
  Main metoden ligger i BinTree, for å kjøre programmet så skriv java BinTree
4.
  jeg gjorde ingen store antakelser med programmet, bortsett fra antakelsen at jeg gjorde ting riktig
5.
  Valgte å starte med en rot node uten innhold, å jeg valgte å gjøre mesteparten av koden inni i noden også starte
  kallene fra selve tree, også har jeg en del test metoder som ble mens jeg jobbet med obliggen, så programmet er litt lengre enn nødvendig.
6.
  Alt burde fungere, statistikken er vanskelig å vite om er riktig,
  et tips til enste gang kan vøre å oppgi statistikken i filen så det er mulig å finne ut om man har riktig
7.
  Jeg ønsker feedback på norsk.
